from enum import Enum


class Language(Enum):
    C = 1
    CPP = 2
    CSHARP = 3
    CSS = 4
    JAVA = 5
    JS = 6
    PHP = 7
    Python = 8
    Ruby = 9
