class IndexerError(Exception):
    pass
